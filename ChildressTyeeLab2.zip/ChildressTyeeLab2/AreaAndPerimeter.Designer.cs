﻿namespace CalculateLetterGrade
{
    partial class AreaAndPerimeter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Calculate = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LengthNumber = new System.Windows.Forms.TextBox();
            this.WidthNumber = new System.Windows.Forms.TextBox();
            this.AreaNumber = new System.Windows.Forms.TextBox();
            this.PerimeterNumber = new System.Windows.Forms.TextBox();
            this.ScoreCalculator = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(40, 186);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(75, 23);
            this.Calculate.TabIndex = 0;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(151, 186);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 1;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Legnth:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Width:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Area:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Perimeter:";
            // 
            // LengthNumber
            // 
            this.LengthNumber.Location = new System.Drawing.Point(98, 27);
            this.LengthNumber.Name = "LengthNumber";
            this.LengthNumber.Size = new System.Drawing.Size(100, 20);
            this.LengthNumber.TabIndex = 6;
            // 
            // WidthNumber
            // 
            this.WidthNumber.Location = new System.Drawing.Point(98, 65);
            this.WidthNumber.Name = "WidthNumber";
            this.WidthNumber.Size = new System.Drawing.Size(100, 20);
            this.WidthNumber.TabIndex = 7;
            // 
            // AreaNumber
            // 
            this.AreaNumber.Location = new System.Drawing.Point(98, 101);
            this.AreaNumber.Name = "AreaNumber";
            this.AreaNumber.Size = new System.Drawing.Size(100, 20);
            this.AreaNumber.TabIndex = 8;
            // 
            // PerimeterNumber
            // 
            this.PerimeterNumber.Location = new System.Drawing.Point(98, 137);
            this.PerimeterNumber.Name = "PerimeterNumber";
            this.PerimeterNumber.Size = new System.Drawing.Size(100, 20);
            this.PerimeterNumber.TabIndex = 9;
            // 
            // ScoreCalculator
            // 
            this.ScoreCalculator.Location = new System.Drawing.Point(74, 215);
            this.ScoreCalculator.Name = "ScoreCalculator";
            this.ScoreCalculator.Size = new System.Drawing.Size(124, 23);
            this.ScoreCalculator.TabIndex = 11;
            this.ScoreCalculator.Text = "ScoreCalculator";
            this.ScoreCalculator.UseVisualStyleBackColor = true;
            this.ScoreCalculator.Click += new System.EventHandler(this.ScoreCalculator_Click);
            // 
            // AreaAndPerimeter
            // 
            this.AcceptButton = this.Calculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.Exit;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.ScoreCalculator);
            this.Controls.Add(this.PerimeterNumber);
            this.Controls.Add(this.AreaNumber);
            this.Controls.Add(this.WidthNumber);
            this.Controls.Add(this.LengthNumber);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Calculate);
            this.Name = "AreaAndPerimeter";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LengthNumber;
        private System.Windows.Forms.TextBox WidthNumber;
        private System.Windows.Forms.TextBox AreaNumber;
        private System.Windows.Forms.TextBox PerimeterNumber;
        private System.Windows.Forms.Button ScoreCalculator;
    }
}