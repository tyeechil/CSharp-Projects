﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateLetterGrade
{
    public partial class AreaAndPerimeter : Form
    {
        public AreaAndPerimeter()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            decimal length = Convert.ToDecimal(LengthNumber.Text);
            decimal width = Convert.ToDecimal(WidthNumber.Text);

            string area= Convert.ToString(length *width);
            string perimeter = Convert.ToString((2* length)+(2*width));

            AreaNumber.Text = area;
            PerimeterNumber.Text = perimeter;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ScoreCalculator_Click(object sender, EventArgs e)
        {
            ScoreCalculator frm = new ScoreCalculator();
            frm.Show();
        }
    }
}
