﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateLetterGrade
{
    public partial class ScoreCalculator : Form
    {
        public ScoreCalculator()
        {
            InitializeComponent();
        }
        int scorecount = 0;
        int total = 0;
        private void Addbtn_Click(object sender, EventArgs e)
        {
            int score = Convert.ToInt32(Scoretext.Text);
            total = total + score;
            Totaltxt.Text = Convert.ToString(total);

            scorecount++;
            Counttext.Text = Convert.ToString(scorecount);
            Scoretext.Clear();

            int average = total / scorecount;
            Averagetext.Text = Convert.ToString(average);
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            total = 0;
            scorecount = 0;
            Scoretext.Clear();
            Totaltxt.Clear();
            Counttext.Clear();
            Averagetext.Clear();



        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
