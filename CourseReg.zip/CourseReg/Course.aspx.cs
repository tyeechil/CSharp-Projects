﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using RegistrationTools;
using System.Data;

namespace CourseReg
{
    public partial class Course : System.Web.UI.Page
    {
        DBConnect objDB = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                UpdateViews();
                GetDepartments();
                GetDayCodes();
                GetProf();
                GetSearchddl();
            }
        }

        protected void AddCoursebtn_Click(object sender, EventArgs e)
        {
            UpdateViews();
            AddCourseform.Visible = true;
        }

        protected void AddCourseSubmitbtn_Click(object sender, EventArgs e)
        {
            string errmessage = "";
            string coursecrn = "";
            string coursetitle = "";
            string coursedept = "";
            string courseterm = "";
            string coursesection = "";
            int courseprofessor = 0;
            string coursedays = "";
            string coursetimestart = "";
            string coursetimeend = "";
            float credithours = 0;
            int maxseats = 0;
            int availseats = 0;

            //Val Course Title
            if (CourseTitletxt.Text == "")
            {
                errmessage += "Yo, you forgot the course title. ";
            }
            else
            {
                coursetitle = CourseTitletxt.Text;
            }

            //Val Course Dpt
            if (Deptddl.SelectedValue == "")
            {
                errmessage += "Yo, you forgot the course department. ";
            }
            else
            {
                coursedept = Deptddl.SelectedValue;
            }

            //Val Course Section
            if (CourseSectiontxt.Text == "")
            {
                errmessage += "Yo, you forgot the course section. ";
            }
            else
            {
                coursesection = CourseSectiontxt.Text;
            }

            //Val Course Term
            if (CourseTermtxt.Text == "")
            {
                errmessage += "Yo, you forgot the course term. ";
            }
            else
            {
                courseterm = CourseTermtxt.Text;
            }

            //Val Course Professor
            if (Profddl.SelectedValue == "")
            {
                errmessage += "Yo, you forgot the course professor. ";
            }
            else
            {
                courseprofessor = Convert.ToInt32(Profddl.SelectedValue);
            }

            //Val Course Day
            if (DayCodeddl.SelectedValue == "")
            {
                errmessage += "Yo, you forgot the course days. ";
            }
            else
            {
                coursedays = DayCodeddl.SelectedItem.ToString();
            }

            //Val Course Start
            if (CourseStartTimetxt.Text == "")
            {
                errmessage += "Yo, you forgot the course start time. ";
            }
            else
            {
                coursetimestart = CourseStartTimetxt.Text;
            }

            //Val Course End
            if (CourseEndTimetxt.Text == "")
            {
                errmessage += "Yo, you forgot the course end time. ";
            }
            else
            {
                coursetimeend = CourseEndTimetxt.Text;
            }

            //Val Course Credit
            if (CourseCreditstxt.Text == "")
            {
                errmessage += "Yo, you forgot the course credits. ";
            }
            else
            {
                credithours = Convert.ToInt32(CourseCreditstxt.Text);
            }
            //Val Course Seats
            if (CourseMaxSeatstxt.Text == "")
            {
                errmessage += "Yo, you forgot the course maximum seating. ";
            }
            else
            {
                maxseats = Convert.ToInt32(CourseMaxSeatstxt.Text);
                availseats = maxseats;
            }
            //END MAJOR VALIDATION

            //IF ERROR
            if (errmessage != "")
            {
                CourseErrorlbl.Text = "Error: " + errmessage;
                CourseErrorlbl.Visible = true;
            }
            else
            {
                //GENERATE COURSE CRN
                CourseErrorlbl.Visible = false;
                coursecrn = GenerateCRN(coursecrn);
                bool newcrn = false;
                while (newcrn == false)
                {
                    for (int k = 0; k < gvCourseList.Rows.Count; k++)
                    {
                        var currentrow = gvCourseList.Rows[k].Cells[0].Text;
                        if (coursecrn == currentrow)
                        {
                            coursecrn = "";
                            coursecrn = GenerateCRN(coursecrn);
                        }
                    }
                    newcrn = true;
                }
                RegistrationOperations.AddCourse(coursecrn, coursetitle, coursedept, courseterm, coursesection, courseprofessor, coursedays, coursetimestart, coursetimeend, credithours, maxseats, availseats);
                UpdateViews();
                ClearAddFields();

            }

        }
        protected void DeleteCoursebtn_Click(object sender, EventArgs e)
        {
            UpdateViews();
            DeleteCourseForm.Visible = true;
        }
        protected void DeleteCourseSubmitbtn_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int row = 0; row < gvDeleteCourse.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvDeleteCourse.Rows[row].FindControl("chkSelect");
                if (CBox.Checked)
                {
                    String CourseCRN = "";
                    CourseCRN = gvDeleteCourse.Rows[row].Cells[1].Text;
                    RegistrationOperations.DeleteCourses(CourseCRN);

                    //arrProducts.Add(CourseCRN);
                    count = count + 1;
                }
            }
            if (count == 0)
            {
                CourseErrorlbl.Text = "You haven't selected any courses to delete!";
                CourseErrorlbl.Visible = true;
            }
            else
            {
                UpdateViews();
            }


        }
        protected void ModifyCoursebtn_Click(object sender, EventArgs e)
        {
            UpdateViews();
            ModifyCourseForm.Visible = true;
        }
        protected void searchgvbtn_Click(object sender, EventArgs e)
        {
            CourseErrorlbl.Text = "";
            CourseErrorlbl.Visible = false;
            //IF DEPT VALUE, NO SEMESTER
            if (ddlDeptsrchtxt.SelectedValue != "" && ddlSemestersrchtxt.SelectedValue == "")
            {
                string CDpt = ddlDeptsrchtxt.SelectedValue;
                gvCourseList.DataSource = RegistrationOperations.GetCoursesWithDepartmentOnly(CDpt);
                gvCourseList.DataBind();
                objDB.ResetConnection();
            }
            //IF SEMESTER VALUE, NO DPT
            else if (ddlDeptsrchtxt.SelectedValue == "" && ddlSemestersrchtxt.SelectedValue != "")
            {
                string CSemester = ddlSemestersrchtxt.SelectedValue.ToString();
                gvCourseList.DataSource = RegistrationOperations.GetCoursesWithSemesterOnly(CSemester);
                gvCourseList.DataBind();
                objDB.ResetConnection();
            }
            //IF BOTH
            else if (ddlDeptsrchtxt.SelectedValue != "" && ddlSemestersrchtxt.SelectedValue != "")
            {
                string CDpt = ddlDeptsrchtxt.SelectedValue;
                string CSemester = ddlSemestersrchtxt.SelectedValue;
                gvCourseList.DataSource = RegistrationOperations.GetCoursesWithDepartmentAndSemester(CDpt, CSemester);
                gvCourseList.DataBind();
                objDB.ResetConnection();
            }
            //IF NEITHER
            else if (ddlDeptsrchtxt.SelectedValue == "" && ddlSemestersrchtxt.SelectedValue == "")
            {
                gvCourseList.DataSource = RegistrationOperations.GetCourses();
                gvCourseList.DataBind();
                objDB.ResetConnection();
            }
            //IF NO TABLE
            if (gvCourseList.Rows.Count == 0)
            {
                gvCourseList.Visible = false;
                CourseErrorlbl.Text = "No Record matching search criteria";
                CourseErrorlbl.Visible = true;
            }
            else
            {
                CourseErrorlbl.Text = "";
                CourseErrorlbl.Visible = false;
            }
            if (CourseErrorlbl.Visible == false)
            {
                gvCourseList.Visible = true;
                CourseErrorlbl.Text = "";
                CourseErrorlbl.Visible = false;
                objDB.ResetConnection();
            }
        }

        protected void UpdateViews()
        {
            GetCourses();
            GetDeleteCourses();
            GetModifyCourses();
        }
        protected void GetDepartments()
        {
            Deptddl.DataSource = RegistrationOperations.GetDepartments();
            Deptddl.DataTextField = "DeptID";
            Deptddl.DataValueField = "DeptID";
            Deptddl.DataBind();
            objDB.ResetConnection();
        }
        protected void GetProf()
        {
            DataSet professors = new DataSet();
            Profddl.DataSource = RegistrationOperations.GetProfessors();
            Profddl.DataTextField = "ProfessorName";
            Profddl.DataValueField = "ProfessorID";
            Profddl.DataBind();
            objDB.ResetConnection();
        }
        protected void GetDayCodes()
        {
            DataSet daycode = new DataSet();
            DayCodeddl.DataSource = RegistrationOperations.GetDayCodes();
            DayCodeddl.DataTextField = "DaysofWeek";
            DayCodeddl.DataValueField = "DaysID";
            DayCodeddl.DataBind();
            objDB.ResetConnection();
        }
        protected void GetCourses()
        {
            gvCourseList.DataSource = RegistrationOperations.GetCourses();
            gvCourseList.DataBind();
            objDB.ResetConnection();
        }
        protected void GetDeleteCourses()
        {
            gvDeleteCourse.DataSource = RegistrationOperations.GetCourses();
            gvDeleteCourse.DataBind();
            objDB.ResetConnection();
        }
        protected void GetModifyCourses()
        {
            gvModifyCourse.DataSource = RegistrationOperations.GetCourses();
            gvModifyCourse.DataBind();
            objDB.ResetConnection();
        }
        protected void GetSearchddl()
        {
            ddlDeptsrchtxt.DataSource = RegistrationOperations.GetDepartments();
            ddlDeptsrchtxt.DataTextField = "DeptID";
            ddlDeptsrchtxt.DataValueField = "DeptID";
            ddlDeptsrchtxt.DataBind();
            objDB.ResetConnection();

            ddlSemestersrchtxt.DataSource = RegistrationOperations.GetSemesters();
            ddlSemestersrchtxt.DataTextField = "Term";
            ddlSemestersrchtxt.DataValueField = "Term";
            ddlSemestersrchtxt.DataBind();
            objDB.ResetConnection();
        }
        protected string GenerateCRN(string courseCRN)
        {
            courseCRN = "";
            Random r = new Random();
            int crnlength = r.Next(3, 6);
            for (int j = 0; j < crnlength; j++)
            {
                courseCRN += r.Next(0, 10);
            }
            return courseCRN;
        }
        protected void gvModifyCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Retrieve and display the value contained in the
            // BoundField for ProductNumber (column index 0) of the row the button was clicked
        }

        // RowEditing event handler that fires when the CommandField Edit button is clicked.
        // There is no double-click that will produce this handler
        protected void gvModifyCourse_RowEditing(Object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            // Set the row to edit-mode in the GridView
            gvModifyCourse.EditIndex = e.NewEditIndex;

            UpdateViews();

        }

        protected void gvModifyCourse_RowUpdating(Object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            //get crn
            int rowIndex = e.RowIndex;
            String CRN = gvModifyCourse.Rows[rowIndex].Cells[0].Text;
            // get title
            TextBox TBox;
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[1].FindControl("txtModCourseTitle");
            string Modcoursetitle = TBox.Text;
            // get dept
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[2].FindControl("txtModCourseDept");
            string Modcoursedept = TBox.Text;
            // get section
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[3].FindControl("txtModCourseSection");
            string Modcoursesection = TBox.Text;
            // get term
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[4].FindControl("txtModCourseTerm");
            string Modcourseterm = TBox.Text;
            // get prof
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[5].FindControl("txtModCourseProf");
            string Modcourseprof = TBox.Text;
            // get daycode
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[6].FindControl("txtModCourseDays");
            string Modcourseday = TBox.Text;
            // get start
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[7].FindControl("txtModCourseStart");
            string Modcoursestart = TBox.Text;
            // get end
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[8].FindControl("txtModCourseEnd");
            string Modcourseend = TBox.Text;
            // get credits
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[9].FindControl("txtModCourseCredit");
            string Modcoursecredit = TBox.Text;
            // get maxseats
            TBox = (TextBox)gvModifyCourse.Rows[rowIndex].Cells[11].FindControl("txtModCourseMaxSeats");
            string Modcoursemaxseats = TBox.Text;

            String strSQL = "UPDATE Course SET CourseTitle= '" + Modcoursetitle + "', " +
                            "DeptID = '" + Modcoursedept + "', " +
                            "Semester = '" + Modcourseterm + "', " +
                            "SectionNumber= " + Modcoursesection + ", " +
                            "ProfessorID = " + Modcoursedept + ", " +
                            "DayCode = '" + Modcourseday + "', " +
                            "TimeStart = '" + Modcoursestart + "', " +
                            "TimeEnd = '" + Modcourseend + "', " +
                            "CreditHours = '" + Modcoursecredit + "', " +
                             "MaxSeats= " + Modcoursemaxseats + " WHERE CRN= '" + CRN + "'";

            objDB.DoUpdate(strSQL);

            gvModifyCourse.EditIndex = -1;

            UpdateViews();
        }

        protected void gvModifyCourse_RowCancelingEdit(Object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            gvModifyCourse.EditIndex = -1;

            UpdateViews();

        }

        protected void studentbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Student.aspx");
        }

        protected void homebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("CourseRegistration.aspx");
        }

        protected void registerbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void AddCancelbtn_Click(object sender, EventArgs e)
        {
            ClearAddFields();
        }

        protected void DeleteCancelbtn_Click(object sender, EventArgs e)
        {
            for (int row = 0; row < gvDeleteCourse.Rows.Count; row++)
            {
                CheckBox CBox;

                CBox = (CheckBox)gvDeleteCourse.Rows[row].FindControl("chkSelect");
                if (CBox.Checked)
                {
                    CBox.Checked = false;
                }
            }
            DeleteCourseForm.Visible = false;
        }

        protected void ModifyCancelbtn_Click(object sender, EventArgs e)
        {
            ModifyCourseForm.Visible = false;
        }
        protected void ClearAddFields()
        {
            CourseErrorlbl.Text = "";
            CourseErrorlbl.Visible = false;
            CourseTitletxt.Text = "";
            Deptddl.SelectedIndex = 0;
            CourseSectiontxt.Text = "";
            CourseTermtxt.Text = "";
            DayCodeddl.SelectedIndex = 0;
            Profddl.SelectedIndex = 0;
            CourseStartTimetxt.Text = "";
            CourseEndTimetxt.Text = "";
            CourseCreditstxt.Text = "";
            CourseMaxSeatstxt.Text = "";
            AddCourseform.Visible = false;
        }
    }
}