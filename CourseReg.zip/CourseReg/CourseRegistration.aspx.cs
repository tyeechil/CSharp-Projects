﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CourseReg
{
    public partial class CourseRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void studentbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Student.aspx");
        }

        protected void coursebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Course.aspx");
        }

        protected void registerbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}