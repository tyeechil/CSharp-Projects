﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Data;

namespace CourseReg
{
    public partial class Register : System.Web.UI.Page
    {
        DBConnect objDB = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {
            GetStudents();
            GetSearchddl();
        }

        protected void StudentIDsrchbtn_Click(object sender, EventArgs e)
        {
            string errmessage = "";
            string studentidval="";
            string studentname = "";
            if (StudentIDsrchtxt.Text == "") {
                errmessage += "Unable to perform operation. Please Enter ID and try again. ";
                RegErrorlbl.Text = errmessage;
                RegErrorlbl.Visible = true;
            }
            else {
                studentidval = StudentIDsrchtxt.Text;
                bool studentexists = false;
                while (studentexists == false)
                {
                    for (int i = 0; i < gvtemp.Rows.Count; i++)
                    {
                        if (studentidval == gvtemp.Rows[i].Cells[0].Text)
                        {
                            studentname =gvtemp.Rows[i].Cells[1].Text;
                            studentexists = true;
                        }
                    }
                    break;
                }
                if (studentexists == false) {
                    errmessage += "Student does not exist in database. PLease register and try again. ";
                    RegErrorlbl.Text = errmessage;
                    RegErrorlbl.Visible = true;
                }
                RegErrorlbl.Text = "";
                RegErrorlbl.Visible =false;
                //end val

                Authticatedlbl.Text = "Welcome: " + studentname;
            }
        }
        protected void GetStudents()
        {
            String strSQL = "SELECT * FROM dbo.Students";
            gvtemp.DataSource = objDB.GetDataSet(strSQL);
            gvtemp.DataBind();
        }
        protected void GetSearchddl()
        {
            String strSQL = "SELECT * FROM Department";
            ddlDeptsrchtxt.DataSource = objDB.GetDataSet(strSQL);
            ddlDeptsrchtxt.DataTextField = "DeptID";
            ddlDeptsrchtxt.DataValueField = "DeptID";
            ddlDeptsrchtxt.DataBind();

            String strSQL1 = "SELECT * FROM Semester";
            ddlSemestersrchtxt.DataSource = objDB.GetDataSet(strSQL1);
            ddlSemestersrchtxt.DataTextField = "Term";
            ddlSemestersrchtxt.DataValueField = "Term";
            ddlSemestersrchtxt.DataBind();
        }
    }
}