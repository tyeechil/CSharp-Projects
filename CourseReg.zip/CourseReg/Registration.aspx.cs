﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using RegistrationTools;
using System.Data;

namespace CourseReg
{
    public partial class Registration : System.Web.UI.Page
    {
        DBConnect objDB = new DBConnect();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gvtemp.DataSource = RegistrationOperations.GetDS("GetStudents");
                gvtemp.DataBind();
                objDB.ResetConnection();

                gvSelectCourse.DataSource = RegistrationOperations.GetCourses();
                gvSelectCourse.DataBind();
                objDB.ResetConnection();
            }

        }

        protected void StudentIDsrchbtn_Click(object sender, EventArgs e)
        {
            RegErrorlbl.Text = "";
            RegErrorlbl.Visible = false;
            string studentidval = "";
            string studentname = "";

            if (StudentIDsrchtxt.Text == "")
            {
                RegErrorlbl.Text = "Please Enter your ID";
                RegErrorlbl.Visible = true;
            }
            else
            {

                studentidval = StudentIDsrchtxt.Text;
                bool studentexists = false;
                for (int i = 0; i < gvtemp.Rows.Count; i++)
                {
                    if (studentidval == gvtemp.Rows[i].Cells[0].Text)
                    {
                        studentexists = true;
                        studentname = gvtemp.Rows[i].Cells[1].Text;
                    }
                }
                if (studentexists == false)
                {
                    RegErrorlbl.Text = "According to our system, you don't exist in our base. Please register your account and try again";
                    RegErrorlbl.Visible = true;
                }
            }
            //End Student Exists Validation
            RegistrationForm.Visible = true;
            AuthorizedUserlbl.Text = studentname;
            AuthorizedUserlbl.Visible = true;
            SelectCourseForm.Visible = true;

        }
        protected void SelectCourseSubmitbtn_Click(object sender, EventArgs e)
        {

            if (validateStudentRegistrationGridView(gvSelectCourse)) //If row is checked and course is open
            {
                for (int i = 0; i< gvSelectCourse.Rows.Count; i++)
                {
                    Label lblError = (Label)gvSelectCourse.Rows[i].FindControl("lblRowError");
                    CheckBox cb = (CheckBox)gvSelectCourse.Rows[i].FindControl("chkSelect");
                    if (cb.Checked)
                    {
                         string studentname = gvtemp.Rows[i].Cells[1].Text;
                        string studentid = gvtemp.Rows[i].Cells[0].Text;
                        DataSet selectedCourses = RegistrationOperations.CRSCheck(gvSelectCourse.Rows[i].Cells[1].Text, studentid);
                        if (selectedCourses.Tables[0].Rows.Count == 0)
                        {
                            lblError.Text = "";

                        }
                        else
                        {
                            lblError.Text = "You are already registered for this course this semester!";
                        }
                    }
                }
            }
        }
        protected void studentbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Student.aspx");
        }

        protected void coursebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Course.aspx");
        }

        protected void homebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("CourseRegistration.aspx");
        }

        private bool validateStudentRegistrationGridView(GridView courses)
        {
            bool studentable = true;
            int count = 0;
            for (int row = 0; row < courses.Rows.Count; row++)
            {
                CheckBox cb = (CheckBox)courses.Rows[row].FindControl("chkSelect");
                if (cb.Checked)
                {
                    count++;
                    if (courses.Rows[row].Cells[13].Text == "O")
                    {
                        //lblError.Text = "";

                    }
                    else
                    {
                        //lblError.Text = "Course is full! Registration is closed.";
                        studentable = false;

                    }
                }

            }
            if (count > 0 && studentable)
            {
                studentable = true;
                // lblLoginError.Text = "";
            }
            else
            {
                studentable = false;
                //lblLoginError.Text = "You must select at least one course to register for!";
            }

            return studentable;
        }
       
        protected void GetSearchddl()
        {
            ddlDeptsrchtxt.DataSource = RegistrationOperations.GetDepartments();
            ddlDeptsrchtxt.DataTextField = "DeptID";
            ddlDeptsrchtxt.DataValueField = "DeptID";
            ddlDeptsrchtxt.DataBind();
            objDB.ResetConnection();

            ddlSemestersrchtxt.DataSource = RegistrationOperations.GetSemesters();
            ddlSemestersrchtxt.DataTextField = "Term";
            ddlSemestersrchtxt.DataValueField = "Term";
            ddlSemestersrchtxt.DataBind();
            objDB.ResetConnection();
        }

        protected void searchgvbtn_Click(object sender, EventArgs e)
        {
            RegErrorlbl.Text = "";
            RegErrorlbl.Visible = false;
            //IF DEPT VALUE, NO SEMESTER
            if (ddlDeptsrchtxt.SelectedValue != "" && ddlSemestersrchtxt.SelectedValue == "")
            {
                string CDpt = ddlDeptsrchtxt.SelectedValue;
                gvSelectCourse.DataSource = RegistrationOperations.GetCoursesWithDepartmentOnly(CDpt);
                gvSelectCourse.DataBind();
                objDB.ResetConnection();
            }
            //IF SEMESTER VALUE, NO DPT
            else if (ddlDeptsrchtxt.SelectedValue == "" && ddlSemestersrchtxt.SelectedValue != "")
            {
                string CSemester = ddlSemestersrchtxt.SelectedValue.ToString();
                gvSelectCourse.DataSource = RegistrationOperations.GetCoursesWithSemesterOnly(CSemester);
                gvSelectCourse.DataBind();
                objDB.ResetConnection();
            }
            //IF BOTH
            else if (ddlDeptsrchtxt.SelectedValue != "" && ddlSemestersrchtxt.SelectedValue != "")
            {
                string CDpt = ddlDeptsrchtxt.SelectedValue;
                string CSemester = ddlSemestersrchtxt.SelectedValue;
                gvSelectCourse.DataSource = RegistrationOperations.GetCoursesWithDepartmentAndSemester(CDpt, CSemester);
                gvSelectCourse.DataBind();
                objDB.ResetConnection();
            }
            //IF NEITHER
            else if (ddlDeptsrchtxt.SelectedValue == "" && ddlSemestersrchtxt.SelectedValue == "")
            {
                gvSelectCourse.DataSource = RegistrationOperations.GetCourses();
                gvSelectCourse.DataBind();
                objDB.ResetConnection();
            }
            //IF NO TABLE
            if (gvSelectCourse.Rows.Count == 0)
            {
                gvSelectCourse.Visible = false;
                RegErrorlbl.Text = "No Record matching search criteria";
                RegErrorlbl.Visible = true;
            }
            else
            {
                RegErrorlbl.Text = "";
                RegErrorlbl.Visible = false;
            }
        }
    }
}