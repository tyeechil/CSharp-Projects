﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;
using System.Data;
using RegistrationTools;

namespace CourseReg
{
    public partial class Student : System.Web.UI.Page
    {
        DBConnect objDB = new DBConnect();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gvStudents.DataSource = RegistrationOperations.GetDS("GetStudents");
                gvStudents.DataBind();
            }

        }

        protected void NewStudentbtn_Click(object sender, EventArgs e)
        {
            NewStudentform.Visible = true;
        }

        protected void NewStudentSubmitbtn_Click(object sender, EventArgs e)
        {
            string errmessage = "";
            string studentname = "";
            string studentid = "";
            string studentphone = "";
            string studentemail = "";
            //name val
            if (StudentNametxt.Text == "")
            {
                errmessage += "You forgot to enter your name. ";
            }
            else
            {
                studentname = StudentNametxt.Text;
            }
            //phone val
            if (StudentPhonetxt.Text == "")
            {
                errmessage += "You forgot to enter your number. ";
            }
            else
            {
                studentphone = StudentPhonetxt.Text;
            }
            //email val
            if (StudentEmailtxt.Text == "")
            {
                errmessage += "You forgot to enter your email. ";
            }
            else
            {
                //val that email exists
                gvtemp.DataSource = RegistrationOperations.GetDS("GetStudents");
                gvtemp.DataBind();
                gvtemp.Visible = false;
                studentemail = StudentEmailtxt.Text;
                int rowsingv = Convert.ToInt32(gvtemp.Rows.Count.ToString());
                for (int i = 0; i < rowsingv; i++)
                {
                    if (studentemail == gvtemp.Rows[i].Cells[2].Text)
                    {
                        errmessage += "There is already an existing account with this email. ";
                    }
                }
            }
            //END VALIDATION

            //IF ERROR
            if (errmessage != "")
            {
                StudentErrorlbl.Text = "Error: " + errmessage;
                StudentErrorlbl.Visible = true;
            }
            else
            {
                //generate studentid
                StudentErrorlbl.Visible = false;
                int findlastrow = gvtemp.Rows.Count - 1;
                int laststudentid = Convert.ToInt32(gvtemp.Rows[findlastrow].Cells[0].Text);
                laststudentid += 1;
                studentid = Convert.ToString(laststudentid);


                //display settings for studentid and student form

                RegistrationOperations.AddStudent(studentname, studentid, studentphone, studentemail);
                NewStudentIDlbl.Text = "Your ID Number is: " + studentid;
                NewStudentIDlbl.Visible = true;
                NewStudentform.Visible = false;
                gvStudents.Visible = true;
            }
        }
       
        protected void homebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("CourseRegistration.aspx");
        }

        protected void coursebtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Course.aspx");
        }

        protected void registerbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}
