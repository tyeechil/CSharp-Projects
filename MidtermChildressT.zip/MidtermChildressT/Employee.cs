﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermChildressT
{
    class Employee : Person
    {
        private string department { get; set; }

        public override string ToString()
        {
            string employee = "Department: " + department;
            return employee;
        }
    }
}
