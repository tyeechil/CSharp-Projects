﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermChildressT
{
    class Person
    {
       

        private string id { get; set; }
        private string firstName { get; set; }
        private string LastName { get; set; }
        public override string ToString()
        {
            
            string person = "ID: " + id + Environment.NewLine + "First Name: " + firstName +Environment.NewLine + "Last Name: " + LastName;
            return person;
        }
        
    }

}
