﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermChildressT
{
    class PeopleList : List<Person>
    {
            List<Person> newlist = new List<Person>();        
        public override string ToString()
        {
             string fulllist = newlist.ToString();
            return fulllist.ToString();
        }
    }
}
