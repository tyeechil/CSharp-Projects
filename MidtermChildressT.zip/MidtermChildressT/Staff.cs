﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermChildressT
{
    class Staff : Employee
    {
        private string hourlyWage { get; set; }
        public override string ToString()
        {
            string staff = "Hourly Wage: " + hourlyWage;
            return staff;
        }
    }
}
