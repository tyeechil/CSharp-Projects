﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermChildressT
{
    class Student : Person
    {
        private string type { get; set; }
        private string major { get; set; }

        public override string ToString()
        {
            string student = "Type: " + type + Environment.NewLine + "Major: " + major;
            return student;
        }
    }
}
