﻿namespace Product_Object_Problem
{
    partial class Form1
    {
      
       

    }
}