﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project1
{
    public class Grading
    {

        public Grading() { }

        public Grading()
        {

        }
        public string CalcInstruct(string[] instructquest)
        {
            int i = 0;
            int Instructnumgrade = 0;
            string Instructlettergrade = "";
            for (i = 0; i < instructquest.Length; i++)
            {
                if (instructquest[i] == "Strongly Agree") {
                    Instructnumgrade += 5;
                }
                else if (instructquest[i] == "Agree")
                {
                    Instructnumgrade += 4;
                }
                else if (instructquest[i] == "Neutral")
                {
                    Instructnumgrade += 3;
                }
                else if (instructquest[i] == "Disagree")
                {
                    Instructnumgrade += 2;
                }
                else if (instructquest[i] == "Strongly Disagree")
                {
                    Instructnumgrade += 1;
                }
            }
           if(36 <= Instructnumgrade){
               Instructlettergrade = "A";
           }
           else if(32 <= Instructnumgrade && Instructnumgrade <36){
               Instructlettergrade = "B";
           }
            else if(28 <= Instructnumgrade && Instructnumgrade <31){
               Instructlettergrade = "C";
           }
            else if(24 <= Instructnumgrade && Instructnumgrade <27){
               Instructlettergrade = "D";
           }
            else {
               Instructlettergrade = "F";
           }
            return Instructlettergrade;
        }
        public string CalcCourse(string[] coursequest)
        {
            int i = 0;
            int Coursenumgrade = 0;
            string Courselettergrade = "";
            for (i = 9; i < 20; i++)
            {
                if (coursequest[i] == "Strongly Agree") {
                    Coursenumgrade += 5;
                }
                else if (coursequest[i] == "Agree")
                {
                    Coursenumgrade += 4;
                }
                else if (coursequest[i] == "Neutral")
                {
                    Coursenumgrade += 3;
                }
                else if (coursequest[i] == "Disagree")
                {
                    Coursenumgrade += 2;
                }
                else if (coursequest[i] == "Strongly Disagree")
                {
                    Coursenumgrade += 1;
                }
            }
            if (54 <= Coursenumgrade)
            {
                Courselettergrade = "A";
           }
            else if (48 <= Coursenumgrade && Coursenumgrade < 53)
            {
                Courselettergrade = "B";
           }
            else if (42 <= Coursenumgrade && Coursenumgrade < 47)
            {
                Courselettergrade = "C";
           }
            else if (36 <= Coursenumgrade && Coursenumgrade < 41)
            {
                Courselettergrade = "D";
           }
            else {
                Courselettergrade = "F";
           }
            return Courselettergrade;
        }
    }
}