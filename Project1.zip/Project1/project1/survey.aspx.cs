﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project1
{
    public partial class survey : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string Name = Request["nametxt"];
            string ID = Request["IDtxt"];
            string[] InstructSurvRes = { Request["question1radio"], Request["question2radio"], Request["question3radio"],
                                   Request["question4radio"], Request["question5radio"], Request["question6radio"],
                                   Request["question7radio"], Request["question8radio"] };
            string[] CourseSurvRes = { Request["question9radio"], Request["question10radio"],
                Request["question11radio"], Request["question12radio"], Request["question13radio"],
                Request["question14radio"], Request["question15radio"],
                Request["question16radio"], Request["question17radio"], Request["question18radio"],
                Request["question19radio"], Request["question20radio"] };
            
            NameLbl.Text = Name;
            IDLbl.Text = ID;
            Quest1Lbl.Text = InstructSurvRes[0];
            Quest2Lbl.Text = InstructSurvRes[1];
            Quest3Lbl.Text = InstructSurvRes[2];
            Quest4Lbl.Text = InstructSurvRes[3];
            Quest5Lbl.Text = InstructSurvRes[4];
            Quest6Lbl.Text = InstructSurvRes[5];
            Quest7Lbl.Text = InstructSurvRes[6];
            Quest8Lbl.Text = InstructSurvRes[7];
            Quest9Lbl.Text = CourseSurvRes[0];
            Quest10Lbl.Text = CourseSurvRes[1];
            Quest11Lbl.Text = CourseSurvRes[2];
            Quest12Lbl.Text = CourseSurvRes[3];
            Quest13Lbl.Text = CourseSurvRes[4];
            Quest14Lbl.Text = CourseSurvRes[5];
            Quest15Lbl.Text = CourseSurvRes[6];
            Quest16Lbl.Text = CourseSurvRes[7];
            Quest17Lbl.Text = CourseSurvRes[8];
            Quest18Lbl.Text = CourseSurvRes[9];
            Quest19Lbl.Text = CourseSurvRes[10];
            Quest20Lbl.Text = CourseSurvRes[11];
            Grading instructor = new Grading();
            InstGradeLbl.Text = instructor.CalcInstruct(InstructSurvRes);
            
        }
    }
}