﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using CreditCardLib;


namespace CCWebService
{
    /// <summary>
    /// Summary description for CardServices
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class CardServices : System.Web.Services.WebService
    {

        //ACCOUNTS

        [WebMethod]
        public DataSet getAccounts()
        {
            return Accounts.getAccounts();
        }
        [WebMethod]
        public void AddNewAccount(string accountid, string accountowner, string accountaddress, string accountcity, string accountstate, string accountzip, string accountphone)
        {
            Accounts.AddNewAccount(accountid, accountowner, accountaddress, accountcity, accountstate, accountzip, accountphone);
        }
        [WebMethod]
        public void UpdateAccount(string accountid, string accountowner, string accountaddress, string accountcity, string accountstate, string accountzip, string accountphone)
        {
            Accounts.UpdateAccount(accountid, accountowner, accountaddress, accountcity, accountstate, accountzip, accountphone);
        }
        [WebMethod]
        public DataSet SearchByAccountID(string SBAcccountID)
        {
            return Accounts.SearchByAccountID(SBAcccountID);
        }
        [WebMethod]
        public DataSet SearchByName(string SBName)
        {
            return Accounts.SearchByName(SBName);
        }
        [WebMethod]
        public DataSet SearchByPhone(string SBPhone)
        {
            return Accounts.SearchByPhone(SBPhone);
        }
        
        //CREDIT CARDS
        [WebMethod]
        public void AddCreditCard(string cardnum, string accountid, string expirationdate, string cvv, float cardlimit, float cardbalance, string pin, string status)
        {
            CreditCards.AddCreditCard(cardnum, accountid, expirationdate, cvv, cardlimit, cardbalance, pin, status);
        }
        [WebMethod]
        public void UpdateCreditCard(string cardnum, string accountid, string expirationdate, string cvv, float cardlimit, float cardbalance, string pin, string status)
        {
            CreditCards.UpdateCC(cardnum, accountid, expirationdate, cvv, cardlimit, cardbalance, pin, status);
        }
        [WebMethod]
        public DataSet SearchByStatus(string SBStatus)
        {
            return CreditCards.SearchByStatus(SBStatus);
        }
        [WebMethod]
        public DataSet SearchByCCNumber(string SBCCNumber)
        {
            return CreditCards.SearchByCCNumber(SBCCNumber);
        }

        //TRANSACTIONS
        [WebMethod]
        public string[] ProcessTransaction(string[] trans_info)
        {
            return Transactions.ProcessTransaction(trans_info);
        }
        [WebMethod]
        public void AddTransaction(string CCNumber, float transamount, DateTime timestamp, string transid) {
            Transactions.AddTransaction(CCNumber,transamount,timestamp,transid);
        }
        [WebMethod]
        public DataSet SearchTransaction(string sbaccountid)
        {
            return Transactions.SearchTransactions(sbaccountid);
        }

    }
}
