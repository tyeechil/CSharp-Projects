﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Utilities;
using Tools;
using System.Data.SqlClient;

namespace CreditCardLib
{
    public class Accounts
    {
        static DBConnect database = new DBConnect();

        public static DataSet getAccounts()
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "GetAccounts";
            return database.GetDataSetUsingCmdObj(newcommand);
        }
        public static void AddNewAccount(string NAccountID,string NAOwner, string NAAddress, string NACity, string NAState, string NAZip, string NAPhone)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "AddNewAccount";
            newcommand.Parameters.AddWithValue("@NAccountID", NAccountID);
            newcommand.Parameters.AddWithValue("@NAOwner", NAOwner);
            newcommand.Parameters.AddWithValue("@NAAddress", NAAddress);
            newcommand.Parameters.AddWithValue("@NACity", NACity);
            newcommand.Parameters.AddWithValue("@NAState", NAState);
            newcommand.Parameters.AddWithValue("@NAZip", NAZip);
            newcommand.Parameters.AddWithValue("@NAPhone", NAPhone);
            database.DoUpdateUsingCmdObj(newcommand);
        }
        public static void UpdateAccount(string UPAccountID, string UPAOwner, string UPAAddress, string UPACity, string UPAState, string UPAZip, string UPAPhone)
        {
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "UpdateAccount";
            newcommand.Parameters.AddWithValue("@UPAccountID", UPAccountID);
            newcommand.Parameters.AddWithValue("@UPAOwner", UPAOwner);
            newcommand.Parameters.AddWithValue("@UPAAddress", UPAAddress);
            newcommand.Parameters.AddWithValue("@UPACity", UPACity);
            newcommand.Parameters.AddWithValue("@UPAState", UPAState);
            newcommand.Parameters.AddWithValue("@UPAZip", UPAZip);
            newcommand.Parameters.AddWithValue("@UPAPhone", UPAPhone);
            database.DoUpdateUsingCmdObj(newcommand);
            database.ResetConnection();
        }
        public static DataSet SearchByAccountID(string SBAccountID)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchByAccountID";
            newcommand.Parameters.AddWithValue("@SBAccountID",SBAccountID);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
        public static DataSet SearchByPhone(string SBPhone)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchByPhone";
            newcommand.Parameters.AddWithValue("@SBPhone", SBPhone);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
        public static DataSet SearchByName(string SBOwner)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchByName";
            newcommand.Parameters.AddWithValue("@SBOwner", SBOwner);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
    }
}
