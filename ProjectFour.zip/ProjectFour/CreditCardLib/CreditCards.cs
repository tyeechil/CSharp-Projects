﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Utilities;

namespace CreditCardLib
{
    public class CreditCards
    {
        static DBConnect database = new DBConnect();
        public static void AddCreditCard(string NCCNumber, string NAccountID, string NExpDate, string NCVV, float NCCLimit, float NCCBalance, string NCCPin,string NCStatus)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "AddCreditCard";
            newcommand.Parameters.AddWithValue("@NCCNumber", NCCNumber);
            newcommand.Parameters.AddWithValue("@NAccountID", NAccountID);
            newcommand.Parameters.AddWithValue("@NExpDate", NExpDate);
            newcommand.Parameters.AddWithValue("@NCVV", NCVV);
            newcommand.Parameters.AddWithValue("@NCCLimit", NCCLimit);
            newcommand.Parameters.AddWithValue("@NCCBalance", NCCBalance);
            newcommand.Parameters.AddWithValue("@NCCPin", NCCPin);
            newcommand.Parameters.AddWithValue("@NCStatus",NCStatus);
            database.DoUpdateUsingCmdObj(newcommand);
        }
        public static void UpdateCC(string UPCCNumber, string NAccountID, string NExpDate, string UPCC_CVV, float UPCCLimit, float UPCCBalance, string UPCCPin, string UPCCStatus)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "UpdateCC";
            newcommand.Parameters.AddWithValue("@UPCCNumber", UPCCNumber);
            newcommand.Parameters.AddWithValue("@UPCCAccountID", NAccountID);
            newcommand.Parameters.AddWithValue("@UPCCExpDate", NExpDate);
            newcommand.Parameters.AddWithValue("@UPCCVV", UPCC_CVV);
            newcommand.Parameters.AddWithValue("@UPCCLimit", UPCCLimit);
            newcommand.Parameters.AddWithValue("@UPCCBalance", UPCCBalance);
            newcommand.Parameters.AddWithValue("@UPCCPin", UPCCPin);
            newcommand.Parameters.AddWithValue("@UPCCStatus", UPCCStatus);
            database.DoUpdateUsingCmdObj(newcommand);
        }
        public static DataSet SearchByStatus(string SBStatus)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchByStatus";
            newcommand.Parameters.AddWithValue("@SBStatus", SBStatus);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
        public static DataSet SearchByCCNumber(string SBCCNumber)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchByCCNumber";
            newcommand.Parameters.AddWithValue("@SBCCNumber", SBCCNumber);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
    }
}
