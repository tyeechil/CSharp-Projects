﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Utilities;
using Tools;
using System.Data.SqlClient;

namespace CreditCardLib
{
    public class Transactions
    {
        static DBConnect database = new DBConnect();
        public static string[] ProcessTransaction(string[] trans_info)
        {
            float checkupdatedbalance;
            //account and card
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "getTransactions";
            newcommand.Parameters.AddWithValue("@CCNum", trans_info[5]);
            DataSet data = database.GetDataSetUsingCmdObj(newcommand);



            if (data.Tables[0].Rows.Count > 0)
            {
                //if card trans_info is valid
                if (data.Tables[0].Rows[0][7].ToString() == trans_info[5] && data.Tables[0].Rows[0][9].ToString() == trans_info[7] && data.Tables[0].Rows[0][10].ToString() == trans_info[8])
                {
                    //if account trans_info is correct
                    if (data.Tables[0].Rows[0][1].ToString() == trans_info[0] && data.Tables[0].Rows[0][2].ToString() == trans_info[1] && data.Tables[0].Rows[0][3].ToString() == trans_info[2] && data.Tables[0].Rows[0][4].ToString() == trans_info[3] && data.Tables[0].Rows[0][5].ToString() == trans_info[4])
                    {
                        float cclimit = float.Parse((data.Tables[0].Rows[0][11].ToString()), System.Globalization.NumberStyles.Currency);
                        float oldccbalance = float.Parse((data.Tables[0].Rows[0][12].ToString()), System.Globalization.NumberStyles.Currency);
                        float transactionAmount = float.Parse(trans_info[9]);

                        if (oldccbalance == cclimit)
                        {
                            checkupdatedbalance = oldccbalance - transactionAmount;
                        }
                        else { checkupdatedbalance = oldccbalance + transactionAmount; }
                        if (checkupdatedbalance <= cclimit)
                        {
                            //create next trans id

                            string strtransid = data.Tables[0].Rows[0][15].ToString();
                            string accnum = strtransid.Split('_')[0];
                            string transnum = strtransid.Split('_')[1];
                            int transidupone = Convert.ToInt32(transnum);
                            transidupone++;
                            trans_info[13] = accnum + "_" + transidupone;
                            trans_info[14] =Convert.ToString(DateTime.Now);
                            //update transaction table
                            AddTransaction(trans_info[5], transactionAmount, DateTime.Now, trans_info[13]);
                            //update card balance
                            float newbalance = oldccbalance - transactionAmount;
                            //update card table
                            UpdateCCfromTransaction(trans_info[5], newbalance);

                            //OK
                            trans_info[10] = "200";
                            trans_info[11] = "Success!";
                            trans_info[12] = "Accepted";

                        }
                        else
                        {
                            //Return error that transaction would exceed limit of card
                            trans_info[10] = "4";
                            trans_info[11] = "Transaction would exceed credit card limit.";
                            trans_info[12] = "Declined";
                        }
                    }
                    else
                    {
                        //Return error code saying customer info is incorrect
                        trans_info[10] = "3";
                        trans_info[11] = "Invalid Account Information";
                        trans_info[12] = "Declined";
                    }
                }
                else
                {
                    //REturn error code saying wrong credit card info
                    trans_info[10] = "2";
                    trans_info[11] = "Invalid Credit Card Info";
                    trans_info[12] = "Declined";
                }
            }
            else
            {
                trans_info[10] = "1";
                trans_info[11] = "Credit Card does not exist!";
                trans_info[12] = "Declined";
            }
            return trans_info;
        }

        public static void AddTransaction(string CCNumber, float transamount, DateTime timestamp, string transid)
        {
            database.ResetConnection();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "AddTransaction";
            objCommand.Parameters.AddWithValue("@TransID", transid);
            objCommand.Parameters.AddWithValue("@TransCCNumber", CCNumber);
            objCommand.Parameters.AddWithValue("@TransAmount", transamount);
            objCommand.Parameters.AddWithValue("@TransDate", timestamp);
            database.DoUpdateUsingCmdObj(objCommand);
        }
        private static void UpdateCCfromTransaction(string CCNumber, float newbalance)
        {
            database.ResetConnection();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "UpdateCCfromTransaction";
            objCommand.Parameters.AddWithValue("@UPCCNumber", CCNumber);
            objCommand.Parameters.AddWithValue("@UPCCBalance", newbalance);
            database.DoUpdateUsingCmdObj(objCommand);
        }
        public static DataSet SearchTransactions(string sbaccountid)
        {
            database.ResetConnection();
            SqlCommand newcommand = new SqlCommand();
            newcommand.CommandType = CommandType.StoredProcedure;
            newcommand.CommandText = "SearchTransaction";
            newcommand.Parameters.AddWithValue("@SBAccountID", sbaccountid);
            return database.GetDataSetUsingCmdObj(newcommand);
        }
    }
}
