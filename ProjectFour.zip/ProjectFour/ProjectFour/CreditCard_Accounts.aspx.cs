﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CCWebService;
using Utilities;

namespace ProjectFour
{
    public partial class CreditCard_Accounts : System.Web.UI.Page
    {
        CardServices CardService = new CardServices();
        DBConnect db = new DBConnect();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getAccounts();
                lblSearchError.Text = "";
                lblSearchError.Visible = false;
            }
        }
        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Main.aspx");
        }

        protected void btnManage_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Accounts.aspx");
        }

        protected void btnTransaction_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Transation.aspx");
        }

        protected void btnCreateCard_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_AddCard.aspx");
        }
        protected void getAccounts()
        {
            DataSet data = CardService.getAccounts();
            gvAccounts.DataSource = data;
         gvAccounts.DataBind();
           
        }

        protected void btnEditAccount_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_EditInformation.aspx");
        }

        protected void btnSearchAccounts_Click(object sender, EventArgs e)
        {
            string errmessage = "";
            if (ddlSearchBy.SelectedValue == "" && txtSearchAccounts.Text !="")
            {
                errmessage += "You have to select a medium to search by before you can enact a search. ";
            }
            else if (txtSearchAccounts.Text == "" && ddlSearchBy.SelectedValue !="")
            {
                errmessage += "You have to enter a value to search by before you can enact a search. ";
            }
            else if (ddlSearchBy.SelectedValue == "" && txtSearchAccounts.Text == "")
            {
                getAccounts();
            }

            if (errmessage != "")
            {
                lblSearchError.Text = errmessage;
                lblSearchError.Visible = true;
            }
            else
            {
                lblSearchError.Visible = false;
                lblSearchError.Text = "";
                if (ddlSearchBy.SelectedValue == "AccountID")
                {
                    string sbaccountid = txtSearchAccounts.Text;
                    DataSet data = CardService.SearchByAccountID(sbaccountid);
                    gvAccounts.DataSource = data;
                    gvAccounts.DataBind();
                    
                }
                else if (ddlSearchBy.SelectedValue == "Name")

                {
                    string sbname = txtSearchAccounts.Text;
                    DataSet data = CardService.SearchByName(sbname);
                    gvAccounts.DataSource = data;
                    gvAccounts.DataBind();
                    
                }
                else if (ddlSearchBy.SelectedValue == "Phone")
                {
                    string sbphone = txtSearchAccounts.Text;
                    DataSet data = CardService.SearchByPhone(sbphone);
                    gvAccounts.DataSource = data;
                    gvAccounts.DataBind();
                    
                }
                else if (ddlSearchBy.SelectedValue == "CCNumber")
                {
                    string sbccnumber = txtSearchAccounts.Text;
                    DataSet data = CardService.SearchByCCNumber(sbccnumber);
                    gvAccounts.DataSource = data;
                    gvAccounts.DataBind();
                    
                }
                else if (ddlSearchBy.SelectedValue == "Status")
                {
                    string sbstatus = txtSearchAccounts.Text;
                    DataSet data = CardService.SearchByCCNumber(sbstatus);
                    gvAccounts.DataSource = data;
                    gvAccounts.DataBind();
                    
                }
            }
        }

    }
}