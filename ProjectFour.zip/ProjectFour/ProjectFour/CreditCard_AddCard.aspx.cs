﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CCWebService;
using System.Data;

namespace ProjectFour
{
    public partial class CreditCard_AddCard : System.Web.UI.Page
    {
        CardServices CardService = new CardServices();

        protected void Page_Load(object sender, EventArgs e)
        {
            Errorlbl.Visible = false;
            gvtemp.Visible = false;
            lblCardInfo.Visible = false;
            lblCardInfo.Text = "";
        }
        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Main.aspx");
        }

        protected void btnManage_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Accounts.aspx");
        }

        protected void btnTransaction_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Transation.aspx");
        }

        protected void btnSubmitNewCardInfo_Click(object sender, EventArgs e)
        {
            string newaccountid;
            string errmessage = "";
            string newcardname = "";
            string newcardaddress = "";
            string newcardcity = "";
            string newcardstate = "";
            string newcardzip = "";
            string newcardphone = "";
           string newcardpin = "";
            float newcardlimit = 0.0f;
            string newcardnumber;
            string newcardcvv;
            string newcardexpiration = GenerateExp();
            string newcardstatus = "Active";
            Errorlbl.Visible = false;
            float newcardbalance = 0.0f;
            if (txtName.Text != "")
            { newcardname = txtName.Text; }
            else { errmessage += "Please Enter a Valid Name. "; }

            if (txtAddress.Text != "")
            { newcardaddress = txtAddress.Text; }
            else { errmessage += "Please Enter a Valid Address. "; }

            if (txtCity.Text != "")
            { newcardcity = txtCity.Text; }
            else { errmessage += "Please Enter a Valid City/Town. "; }

            if (ddlState.SelectedValue != "")
            { newcardstate = ddlState.SelectedValue; }
            else { errmessage += "Please Enter a Valid State. "; }

            if (txtZip.Text !="")
            { newcardzip = txtZip.Text; }
            else { errmessage += "Please Enter a Valid Zip Code. "; }

            if (txtPhone.Text != "")
            { newcardphone = txtPhone.Text; }
            else { errmessage += "Please Enter a Valid Phone Number. "; }

            if (txtPin.Text != "")
            { newcardpin = txtPin.Text; }
            else { errmessage += "Please Enter a Valid Pin. "; }

            if (txtLimit.Text != "")
            {
                newcardlimit = float.Parse(txtLimit.Text);
                 newcardbalance = newcardlimit;
            }
            else { errmessage += "Please Enter a Valid Limit. "; }

            if (errmessage == "")
            {
                newcardnumber = GenerateNewCCNumber();
                newcardcvv = GenerateNewCVV();
                newaccountid = CreateAccountID();
                CardService.AddNewAccount(newaccountid,newcardname,newcardaddress,newcardcity,newcardstate,newcardzip,newcardphone);
                CardService.AddCreditCard(newcardnumber,newaccountid,newcardexpiration,newcardcvv,newcardlimit,newcardbalance,newcardpin,newcardstatus);
                lblCardInfo.Text = "Card Creation Successful!\r\n The card number is: " +newcardnumber+".\r\n" +
                    "The CVV is: " + newcardcvv +".\r\n" +
                    "Card Expiration Date: " +newcardexpiration;
                CardService.AddTransaction(newcardnumber, 0.0f, DateTime.Now, (newaccountid + "_0"));
                lblCardInfo.Visible = true;

            }
            else
            {Errorlbl.Text = errmessage;
                Errorlbl.Visible = true;
            }
        }
        protected string GenerateNewCCNumber()
        {
            string cardnumber = "4421";
            Random r = new Random();
            for (int j = 0; j < 12; j++)
            {
                cardnumber += r.Next(0, 10);
            }
            return cardnumber;
        }
        protected string GenerateNewCVV()
        {
            string CVV = "";
            Random r = new Random();
            for (int j = 0; j < 3; j++)
            {
                CVV += r.Next(0, 10);
            }
            return CVV;
        }
        protected string GenerateExp()
        {
            DateTime dt = DateTime.Now;
            string month = "";
            bool validmonth = false;
            Random r = new Random();
            while (validmonth == false)
            {
                for (int j = 0; j < 2; j++)
                {
                    month += r.Next(0, 10);
                }
                if (Convert.ToInt32(month) < 13)
                {
                    validmonth = true;
                }
                else
                {
                    month = "";
                }
            }
            int currentyear=Convert.ToInt32(Convert.ToString(dt.Year).Remove(0,2));
            int finalyear = currentyear + 5;
            
               
            string expdate = month + "/" + finalyear;
            return expdate;

        }
        protected string CreateAccountID() {
            string accountid = "87";
            Random r = new Random();
            for (int j = 0; j < 3 ; j++)
            {
                accountid += r.Next(0, 10);
            }
            return accountid;
        }
    }
}