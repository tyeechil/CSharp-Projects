﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using CCWebService;

namespace ProjectFour
{
    public partial class CreditCard_EditInformation : System.Web.UI.Page
    {
        CardServices CardService = new CardServices();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Errorlbl.Visible = false;
                getAccounts();
                lblAccountUpdate.Text = "";
                lblAccountUpdate.Visible = false;

            }
        }
        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Main.aspx");
        }

        protected void btnManage_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Accounts.aspx");
        }

        protected void btnTransaction_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Transation.aspx");
        }

        protected void gvAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtName.Text = gvAccounts.SelectedRow.Cells[2].Text;
            txtAddress.Text = gvAccounts.SelectedRow.Cells[3].Text;
            txtCity.Text = gvAccounts.SelectedRow.Cells[4].Text;
            ddlState.SelectedValue = gvAccounts.SelectedRow.Cells[5].Text;
            txtZip.Text = gvAccounts.SelectedRow.Cells[6].Text;
            txtPhoneNumber.Text = gvAccounts.SelectedRow.Cells[7].Text;

            txtCCNumber.Text = gvAccounts.SelectedRow.Cells[8].Text;
            txtPin.Text = gvAccounts.SelectedRow.Cells[9].Text;
            txtExpDate.Text = gvAccounts.SelectedRow.Cells[10].Text;
            txtCVV.Text= gvAccounts.SelectedRow.Cells[11].Text;
            txtCCLimit.Text = gvAccounts.SelectedRow.Cells[12].Text;
            ddlCardStatus.SelectedValue = gvAccounts.SelectedRow.Cells[14].Text;

        }
        protected void getAccounts()
        {
            DataSet data = CardService.getAccounts();
            gvAccounts.DataSource = data;
            gvAccounts.DataBind();
        }

        protected void btnUpdateAccount_Click(object sender, EventArgs e)
        {
            string upaccountid = gvAccounts.SelectedRow.Cells[1].Text;
            string upaccountowner= txtName.Text;
            string upaccountaddress= txtAddress.Text;
            string upaccountcity = txtCity.Text;
            string upaccountstate = ddlState.SelectedValue;
            string upaccountzip = txtZip.Text;
            string upaccountphone = txtPhoneNumber.Text;
            CardService.UpdateAccount(upaccountid,upaccountowner,upaccountaddress,upaccountcity,upaccountstate,upaccountzip,upaccountphone);
            getAccounts();
        }

        protected void btnUpdateCC_Click(object sender, EventArgs e)
        {
            string upaccountid = gvAccounts.SelectedRow.Cells[1].Text;
            string upccnumber = txtCCNumber.Text;
            string upccpin = txtPin.Text;
            string upccexpdate = txtExpDate.Text;
            string upcc_cvv =  txtCVV.Text;
            float upcclimit = float.Parse(txtCCLimit.Text, System.Globalization.NumberStyles.Currency);
            float upccbalance = float.Parse(gvAccounts.SelectedRow.Cells[13].Text,System.Globalization.NumberStyles.Currency);
            string upccstatus= ddlCardStatus.SelectedValue;
            CardService.UpdateCreditCard(upccnumber,upaccountid,upccexpdate,upcc_cvv,upcclimit,upccbalance,upccpin,upccstatus);
            getAccounts();
        }
    }
}