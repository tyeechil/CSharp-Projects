﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CCWebService;
using System.Data;
using System.Text.RegularExpressions;


namespace ProjectFour
{
    public partial class CreditCard_Transaction : System.Web.UI.Page
    {
        CardServices CardService = new CardServices();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblTransactionError.Visible = false;
                lblProcessedTransaction.Visible = false;
                divMakeTransactionForm.Visible = false;
                lblErrorSearchTransactions.Visible = false;
                divViewTransactionForm.Visible = false;
                divgvShowTransactions.Visible = false;
                gvtemp.Visible = false;

            }

        }
        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Main.aspx");
        }

        protected void btnManage_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Accounts.aspx");
        }

        protected void btnTransaction_Click(object sender, EventArgs e)
        {
            Response.BufferOutput = true;
            Response.Redirect("CreditCard_Transation.aspx");
        }

        protected void btnMakeTransaction_Click(object sender, EventArgs e)
        {
            lblTransactionError.Visible = false;
            lblProcessedTransaction.Visible = false;
            string[] trans_info = new string[15];
            if (isValid())
            {
                //Account Info
                trans_info[0] = txtName.Text;
                trans_info[1] = txtAddress.Text;
                trans_info[2] = txtCity.Text;
                trans_info[3] = ddlState.SelectedValue;
                trans_info[4] = txtZip.Text;
                //Card and Transaction Info
                trans_info[5] = txtCCNumber.Text;
                trans_info[6] = txtPin.Text;
                trans_info[7] = txtExpDate.Text;
                trans_info[8] = txtCVV.Text;
                trans_info[9] = txtTransactionAmount.Text;
                //Returned Codes ,Messages, transaction status
                trans_info[10] = "";
                trans_info[11] = "";
                trans_info[12] = "";
                trans_info[13] = "";
                trans_info[14] = "";
                trans_info = CardService.ProcessTransaction(trans_info);
                if (trans_info[10] == "200") {
                    ClearInputs();
                    
                }
                
                lblProcessedTransaction.Text = trans_info[10] + "<br />" + trans_info[11] + "<br />" + trans_info[12] + "<br/>" + trans_info[14];
                lblProcessedTransaction.Visible = true;
            }
        }
        private bool isValid()

        {
            bool valid = true;
            string errmessage = "";
            Regex creditCardPattern = new Regex("^(?:[0-9]{16})$");
            Regex expDatePattern = new Regex("^(0[1-9]|1[0-2])/([0-9][0-9])$");
            Regex cvvPattern = new Regex("^(?:[0-9]{3})$");
            Regex transactionAmountPattern = new Regex(@"[0-9]+\.[0-9][0-9](?:[^0-9]|$)");

            //Name
            if (txtName.Text == "")
            {
                errmessage += "Please fill in your name. " + "<br />";

            }

            //Credit Card Number
            if (txtCCNumber.Text == "" || !creditCardPattern.IsMatch(txtCCNumber.Text))
            {
                errmessage += "Incorrect Card Information. " + "<br />";

            }
            //Expiration Date
            if (txtExpDate.Text == "" || !expDatePattern.IsMatch(txtExpDate.Text))
            {
                errmessage += "Incorrect Card Information (Expire). " + "<br />";

            }


            //CVV
            if (txtCVV.Text == "" && cvvPattern.IsMatch(txtCVV.Text))
            {
                errmessage += "Incorrect Card Information (CVV). " + "<br />";
            }

            if (txtAddress.Text == "")
            {
                errmessage += "Incorrect Card Information (Address). " + "<br />";
            }
            if (txtCity.Text == "")
            {
                errmessage += "Incorrect Card Information (City). " + "<br />";
            }
            if (ddlState.SelectedValue == "")
            {
                errmessage += "Incorrect Card Information (State). " + "<br />";
            }
            if (txtZip.Text == "")
            {
                errmessage += "Incorrect Card Information (Zip Code). " + "<br />";
            }
            if (txtTransactionAmount.Text == "" || transactionAmountPattern.IsMatch(txtTransactionAmount.Text))
            {
                errmessage += "Invalid Transaction Amount. " + "<br />";
            }
            if (errmessage != "")
            {
                valid = false;
                lblTransactionError.Text = errmessage;
                lblTransactionError.Visible = true;
            }
            else
            {
                lblTransactionError.Text = "";
                lblTransactionError.Visible = false;
                valid = true;
            }
            return valid;
        }
        public void ClearInputs()
        {
            txtName.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            ddlState.SelectedValue = "";
            txtZip.Text = "";
            txtCCNumber.Text = "";
            txtPin.Text = "";
            txtExpDate.Text = "";
            txtCVV.Text = "";
            txtTransactionAmount.Text = "";
        }

        protected void btnSearchTransactionsbyAccountID_Click(object sender, EventArgs e)
        {
            if (txtSearchAccountID.Text=="") {
                lblErrorSearchTransactions.Text = "Please enter a valid Account ID";
                lblErrorSearchTransactions.Visible = true;
            }
            else
            {
                lblErrorSearchTransactions.Text = "";
                lblErrorSearchTransactions.Visible = false;
                string sbaccountid = txtSearchAccountID.Text;
                DataSet data = CardService.SearchTransaction(sbaccountid);
                    gvShowTransactions.DataSource = data;
                    gvShowTransactions.DataBind();
                DataSet data1 = CardService.SearchByAccountID(sbaccountid);
                gvtemp.DataSource = data1;
                gvtemp.DataBind();
                bool idindatabase = false;
                while (idindatabase== false)
                {
                    for(int i=0;i< gvtemp.Rows.Count; i++)
                    {
                        if (sbaccountid == gvtemp.Rows[i].Cells[0].Text) {
                            idindatabase = true;
                        }
                    }
                }
                if (gvShowTransactions.Rows.Count==0 && idindatabase == false) {
                    lblErrorSearchTransactions.Text = "Account Does Not Exist";
                    lblErrorSearchTransactions.Visible = true;
                }
                else if (gvShowTransactions.Rows.Count == 0 && idindatabase == true) {
                    lblErrorSearchTransactions.Text = "No Transactions Have been made.";
                    lblErrorSearchTransactions.Visible = true;
                }
                else {
                    lblErrorSearchTransactions.Text = "";
                    lblErrorSearchTransactions.Visible = false;                                     
                }
            }
            divgvShowTransactions.Visible = true;
            gvShowTransactions.Visible = true;
        }

        protected void btnShowViewTransaction_Click(object sender, EventArgs e)
        {
            divMakeTransactionForm.Visible = false;
            divViewTransactionForm.Visible = true;
        }

        protected void btnShowMakeTransaction_Click(object sender, EventArgs e)
        {
            divViewTransactionForm.Visible = false;
            divMakeTransactionForm.Visible = true;
        }

        protected void btnCancelMakeTransaction_Click(object sender, EventArgs e)
        {
            ClearInputs();
            divMakeTransactionForm.Visible = false;
        }

        protected void btnCancelViewTransaction_Click(object sender, EventArgs e)
        {
            txtSearchAccountID.Text = "";
            gvShowTransactions.Dispose();
            gvtemp.Dispose();
            divViewTransactionForm.Visible = false;
        }
    }
}