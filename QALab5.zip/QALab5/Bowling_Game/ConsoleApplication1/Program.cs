﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bowling_Game;

namespace ConsoleApplication1
{
    class Program
    {
       public static void Main(string[] args)
        {
            Console.Write("Welcome to the Bowling SCore Calculator!");
            Console.Write("Please Enter 20 numbers, each followed by hitting enter:");
            int total = 0;
            for (int i = 0; i < 20; i++)
            {
                string usrInput = Console.ReadLine();
                int input = Int32.Parse(usrInput);
                
            }
            Console.Write(total);
            Console.ReadKey();
        }
    }
}

